//
//  SpartieMessagesV1App.swift
//  SpartieMessagesV1
//
//  Created by Ming on 1/27/25.
//

import SwiftUI

@main
struct SpartieMessagesV1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
